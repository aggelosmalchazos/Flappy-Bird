#include "raylib.h"

#include "state.h"
#include "interface.h"
#include "ADTList.h"
// Assets
Texture ball_img;
Texture star_img;
Sound game_over_snd;
Font font;
void interface_init()
{
	// Αρχικοποίηση του παραθύρου
	InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "game");
	SetTargetFPS(60);
	InitAudioDevice();

	// Φόρτωση εικόνων και ήχων
	ball_img = LoadTextureFromImage(LoadImage("assets/pokeball.png"));
	game_over_snd = LoadSound("assets/game_over.mp3");
	star_img = LoadTextureFromImage(LoadImage("assets/poke.png"));
	font = LoadFont("assets/setback.png");
}

void interface_close()
{
	CloseAudioDevice();
	CloseWindow();
}

// Draw game (one frame)
void interface_draw_frame(State state)
{
	BeginDrawing();
	float x_offset = (SCREEN_WIDTH / 5 - state_info(state)->ball->rect.x);
	// Καθαρισμός, θα τα σχεδιάσουμε όλα από την αρχή
	ClearBackground(RAYWHITE);
	List objects = state_objects(state, state_info(state)->ball->rect.x - SCREEN_WIDTH, state_info(state)->ball->rect.x + 2 * SCREEN_WIDTH);

	// Σχεδιάζουμε τον χαρακτήρα και τις 2 μπάλες

	DrawTexture(ball_img, state_info(state)->ball->rect.x + x_offset, state_info(state)->ball->rect.y, WHITE);

	for (ListNode node = list_first(objects);
		 node != LIST_EOF;
		 node = list_next(objects, node))
	{
		Object obj = list_node_value(objects, node);
		// DrawRectangle(obj->rect.x, obj->rect.y, obj->rect.width, obj->rect.height, BLACK);
		if (obj->type == PLATFORM)
		{
			if (!obj->unstable)
			{
				DrawRectangle(obj->rect.x + x_offset, obj->rect.y, obj->rect.width, obj->rect.height, GREEN);
			}
			else
			{
				DrawRectangle(obj->rect.x + x_offset, obj->rect.y, obj->rect.width, obj->rect.height, RED);
			}
		}
		else if (obj->type == STAR)
		{
			DrawTexture(star_img, obj->rect.x + x_offset, obj->rect.y, WHITE);
		}
	}
	// Σχεδιάζουμε το σκορ και το FPS counter
	DrawText(TextFormat("%04i", state_info(state)->score), 20, 20, 40, PURPLE);
	DrawFPS(SCREEN_WIDTH - 80, 0);
	// DrawTextEx(font, TextFormat("%04i", state_info(state)->score), 20, 20, 40, PURPLE);
	//  Αν το παιχνίδι έχει τελειώσει, σχεδιάζομαι το μήνυμα για να ξαναρχίσει
	if (!state_info(state)->playing)
	{
		DrawText(
			"PRESS [ENTER] TO PLAY AGAIN",
			GetScreenWidth() / 2 - MeasureText("PRESS [ENTER] TO PLAY AGAIN", 20) / 2,
			GetScreenHeight() / 2 - 50, 20, GRAY);
	}

	// Ηχος, αν είμαστε στο frame που συνέβη το game_over
	if (state_info(state)->playing && state_info(state)->paused)
	{
		PlaySound(game_over_snd);
	}
	EndDrawing();
}