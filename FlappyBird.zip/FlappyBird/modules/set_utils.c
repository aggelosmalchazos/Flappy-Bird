#include <stdio.h>
#include "ADTSet.h"
#include "set_utils.h"
#include <stdlib.h>
int *create_int(int value)
{
    int *pointer = malloc(sizeof(int)); // δέσμευση μνήμης
    *pointer = value;                   // αντιγραφή του value στον νέο ακέραιο
    return pointer;
}

int compare_ints(Pointer a, Pointer b)
{
    int *ia = a;
    int *ib = b;
    return *ia - *ib; // αρνητικός, μηδέν ή θετικός, ανάλογα με τη διάταξη των a,b
}

Pointer set_find_eq_or_greater(Set set, Pointer value)
{
    if (set_size(set) == 0)
    {
        return NULL;
    }
    SetNode node;
    node = set_find_node(set, value);
    if (node == NULL)
    {
        set_insert(set, value);
        node = set_next(set, set_find_node(set, value));
        set_remove(set, value);
        return set_node_value(set, node);
    }
    return set_node_value(set, node);
}

Pointer set_find_eq_or_smaller(Set set, Pointer value)
{
    if (set_size(set) == 0)
    {
        return NULL;
    }
    SetNode node;
    node = set_find_node(set, value);
    if (node == NULL)
    {
        set_insert(set, value);
        node = set_previous(set, set_find_node(set, value));
        set_remove(set, value);
        return set_node_value(set, node);
    }
    return set_node_value(set, node);
}
