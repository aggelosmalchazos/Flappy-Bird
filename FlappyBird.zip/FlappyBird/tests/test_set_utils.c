#include <stdio.h>
#include <stdlib.h>
#include "set_utils.h"
#include "ADTSet.h"
#include "acutest.h"


void test_greater()
{
    // Έλεγχος για άδειο set
    int* key = create_int(5);
    Set set1 = set_create(compare_ints, free);
    Pointer temp = set_find_eq_or_greater(set1, key);
    TEST_CHECK(temp == NULL);


    // Έλεγχος για το 5 σε set με στοιχεία 0...9
    for (int i=0 ; i<10 ; i++) {
        set_insert(set1, create_int(i));
    }
    temp = set_find_eq_or_greater(set1, key);
    TEST_CHECK(*(int*)temp == 5);


    //Έλεγχος για το 5 σε set χωρίς το 5
    set_remove(set1, key);
    temp = set_find_eq_or_greater(set1, key);
    TEST_CHECK(*(int*)temp == 6);

    set_destroy(set1);
}

void test_smaller()
{
    //Έλεγχος για άδειο set
    int* key = create_int(5);
    Set set1 = set_create(compare_ints, free);
    Pointer temp = set_find_eq_or_smaller(set1, key);
    TEST_CHECK(temp == NULL);


    //Έλεγχος για το 5 σε set με στοιχεία 0...9
    for (int i=0 ; i<10 ; i++) {
        set_insert(set1, create_int(i));
    }
    temp = set_find_eq_or_smaller(set1, key);
    TEST_CHECK(*(int*)temp == 5);


    //Έλεγχος για το 5 σε set χωρίς το 5
    set_remove(set1, key);
    temp = set_find_eq_or_smaller(set1, key);
    TEST_CHECK(*(int*)temp == 4);

    set_destroy(set1);
}


// Λίστα με όλα τα tests προς εκτέλεση
TEST_LIST = {
    { "test_greater", test_greater },
    { "test_smaller", test_smaller },

    { NULL, NULL } // τερματίζουμε τη λίστα με NULL
};