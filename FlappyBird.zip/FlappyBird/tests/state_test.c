//////////////////////////////////////////////////////////////////
//
// Test για το state.h module
//
//////////////////////////////////////////////////////////////////

#include "acutest.h" // Απλή βιβλιοθήκη για unit testing

#include "state.h"

void test_state_create()
{

	State state = state_create();
	TEST_ASSERT(state != NULL);

	StateInfo info = state_info(state);
	TEST_ASSERT(info != NULL);

	TEST_ASSERT(info->playing);
	TEST_ASSERT(!info->paused);
	TEST_ASSERT(info->score == 0);

	// Προσθέστε επιπλέον ελέγχους
	List objects = state_objects(state, 0, SCREEN_WIDTH);
	TEST_ASSERT(objects != NULL);
}

void test_state_update()
{
	State state = state_create();
	TEST_ASSERT(state != NULL && state_info(state) != NULL);

	// Πληροφορίες για τα πλήκτρα (αρχικά κανένα δεν είναι πατημένο)
	struct key_state keys = {false, false, false, false, false, false, false};

	// Χωρίς κανένα πλήκτρο, η μπάλα μετακινείται 4 pixels δεξιά
	Rectangle old_rect = state_info(state)->ball->rect;
	state_update(state, &keys);
	Rectangle new_rect = state_info(state)->ball->rect;

	TEST_ASSERT(new_rect.x == old_rect.x + 4);

	// Με πατημένο το δεξί βέλος, η μπάλα μετακινείται 6 pixels δεξιά
	keys.right = true;
	old_rect = state_info(state)->ball->rect;
	state_update(state, &keys);
	new_rect = state_info(state)->ball->rect;

	TEST_CHECK(new_rect.x == old_rect.x + 6);

	// Προσθέστε επιπλέον ελέγχους
	keys.left = true;
	keys.right = false;
	old_rect = state_info(state)->ball->rect;
	state_update(state, &keys);
	new_rect = state_info(state)->ball->rect;

	TEST_CHECK(new_rect.x == old_rect.x + 1);
	keys.left = false;

	state_info(state)->ball->vert_mov = FALLING;
	Object first_ball = state_info(state)->ball;
	state_update(state, &keys);
	Object new_ball = state_info(state)->ball;
	TEST_CHECK(new_ball->rect.y == first_ball->rect.y - first_ball->vert_speed);
	TEST_CHECK(new_ball->vert_speed == (double)(10 / 100) * first_ball->vert_speed);

	// τεστ για idle
	first_ball = state_info(state)->ball;
	List objects = state_objects(state, 0, 5 * SCREEN_WIDTH);
	Object platform;
	for (ListNode node = list_first(objects);
		 node != LIST_EOF;
		 node = list_next(objects, node))
	{
		platform = list_node_value(objects, node);
		if (platform->type == PLATFORM)
		{
			break;
		}
	}

	// Έλεγχος για συλλογή αστεριών
	first_ball = state_info(state)->ball;
	objects = state_objects(state, 0, 5 * SCREEN_WIDTH);
	Object star = platform;
	int old_score = state_info(state)->score;
	for (ListNode node = list_first(objects);
		 node != LIST_EOF;
		 node = list_next(objects, node))
	{
		star = list_node_value(objects, node);
		if (star->type == STAR)
		{
			break;
		}
	}
	first_ball->vert_mov = FALLING;
	first_ball->rect.x = star->rect.x - first_ball->rect.width;
	first_ball->rect.y = star->rect.y;
	state_update(state, &keys);
	TEST_CHECK(state_info(state)->score == old_score + 10);

	// έλεγχος αν πλατφόρμα έφτασε το κάτω μέρος της οθόνης και διαγραφή από vector
	platform->rect.y = SCREEN_HEIGHT - platform->rect.height;
	platform->vert_mov = FALLING;
	platform->unstable = true; // ΑΝ ΠΑΕΙ ΚΑΤΙ ΣΤΡΑΒΑ ΑΡΓΟΤΕΡΑ ΠΑΙΙΙΙΙΙΖΕΙ ΝΑ ΕΧΕΙΣ ΛΟΥΣΕΙ ΕΔΩ ΠΕΡΑ
	int size_before = list_size(state_objects(state, 0, 5 * SCREEN_WIDTH));
	state_update(state, &keys);
	// printf("before is %d\n", size_before);
	// printf("after is %d\n", list_size(state_objects(state, 0, 10** SCREEN_WIDTH)));
	TEST_CHECK(list_size(state_objects(state, 0, 5 * SCREEN_WIDTH)) == size_before - 1);
}

// Λίστα με όλα τα tests προς εκτέλεση
TEST_LIST = {
	{"test_state_create", test_state_create},
	{"test_state_update", test_state_update},

	{NULL, NULL} // τερματίζουμε τη λίστα με NULL
};